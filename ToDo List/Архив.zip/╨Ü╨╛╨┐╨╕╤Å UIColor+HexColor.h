//
//  UIColor+HexColor.h
//  ToDo List
//
//  Created by Viktor on 11.09.15.
//  Copyright (c) 2015 Viktor. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIColor (HexColor)
//ввод цвета hex--------------------------
+(UIColor *)colorWithHexString:(NSString *)hexString;

@end
